import React from 'react';

// Fix: Use a dedicated interface for props to ensure proper type checking for children.
interface StepProps {
  number: number;
  title: string;
  children: React.ReactNode;
}

// Fix: Explicitly type Step as a React.FC to help TypeScript correctly infer the children prop from JSX.
const Step: React.FC<StepProps> = ({ number, title, children }) => (
  <div className="mb-6 p-6 bg-gray-50 dark:bg-gray-700 rounded-xl shadow-sm">
    <h3 className="text-xl font-semibold text-[var(--primary-color)] mb-2">
      <span className="bg-[var(--primary-color)] text-white rounded-full w-8 h-8 inline-flex items-center justify-center mr-3">{number}</span>
      {title}
    </h3>
    <p className="text-gray-600 dark:text-gray-300 ml-11">{children}</p>
  </div>
);


const TutorPage: React.FC<{ setCurrentPage: (page: string) => void }> = ({ setCurrentPage }) => {
  const handleLinkClick = (page: string) => {
    setCurrentPage(page);
  };
  
  const linkButtonClasses = "font-semibold text-[var(--primary-color)] hover:underline focus:underline focus:outline-none px-1 transition";

  return (
    <div className="p-4 sm:p-6 md:p-8 max-w-3xl mx-auto">
      <header className="text-center mb-8">
        <h1 className="text-4xl font-bold text-[var(--primary-color)]">📖 Tutorial Interaktif</h1>
        <p className="text-lg text-gray-600 dark:text-gray-400 mt-2">Klik tautan di dalam teks untuk langsung ke halaman terkait.</p>
      </header>

      <div className="bg-white dark:bg-gray-800 p-6 rounded-2xl shadow-lg">
        <Step number={1} title="Tambah Data Siswa">
          Klik tombol 
          <button onClick={() => handleLinkClick('home')} className={linkButtonClasses}>
            "Tambah Siswa"
          </button> 
          di halaman utama. Isi semua kolom yang diperlukan, lalu klik "Simpan Siswa".
        </Step>
        
        <Step number={2} title="Edit & Hapus Data Siswa">
          Pergi ke halaman 
          <button onClick={() => handleLinkClick('data_siswa')} className={linkButtonClasses}>
            Data Siswa
          </button>
          . Pada tabel, klik ikon pensil (✏️) untuk mengedit, atau ikon tong sampah (🗑️) untuk menghapus data.
        </Step>

        <Step number={3} title="Filter & Pencarian">
          Klik tombol 
          <button onClick={() => handleLinkClick('data_siswa')} className={linkButtonClasses}>
            "Filter & Cari Siswa"
          </button>
          . Anda dapat mencari berdasarkan nama atau kriteria lain. Klik "Terapkan Filter" untuk melihat hasilnya.
        </Step>
        
        <Step number={4} title="Kustomisasi Tampilan">
          Buka halaman 
           <button onClick={() => handleLinkClick('settings')} className={linkButtonClasses}>
            Pengaturan
          </button>
          untuk mengubah tema (gelap/terang) dan warna aksen aplikasi.
        </Step>

        <Step number={5} title="Menggunakan API Key Pribadi">
          Untuk pengalaman terbaik dengan Asisten AI, Anda bisa menggunakan API Key Gemini Anda sendiri. Kunjungi 
          <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className={linkButtonClasses}>
            Google AI Studio
          </a> 
          untuk membuat API Key gratis. Setelah itu, buka halaman 
          <button onClick={() => handleLinkClick('settings')} className={linkButtonClasses}>
              Pengaturan
          </button>
          , tempelkan key Anda di kolom yang tersedia, dan simpan.
        </Step>
        
        <div className="text-center mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
          <p className="text-gray-500 dark:text-gray-400 italic">🎌 Semoga tutorial ini membantu, jika ada pertanyaan jangan ragu untuk bertanya~ Rawrrr 🦖</p>
        </div>
      </div>
    </div>
  );
};

export default TutorPage;