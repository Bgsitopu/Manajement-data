
export interface Student {
  id: string;
  nama: string;
  umur: number;
  kelas: string;
  gender: 'L' | 'P' | '';
  ssw: string;
  tb: number;
  bb: number;
}